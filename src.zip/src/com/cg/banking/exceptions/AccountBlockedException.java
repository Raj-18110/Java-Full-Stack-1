package com.cg.banking.exceptions;

@SuppressWarnings("serial")
public class AccountBlockedException extends Exception{
	public AccountBlockedException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AccountBlockedException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public AccountBlockedException(String message) {
		super(message);
	}

	public AccountBlockedException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
	
}
