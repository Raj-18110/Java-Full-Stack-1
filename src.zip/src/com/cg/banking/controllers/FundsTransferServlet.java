package com.cg.banking.controllers;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
@WebServlet("/FundsTransfer")
public class FundsTransferServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;  
    public FundsTransferServlet() { }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BankingServices bankingServices=new BankingServicesImpl();
		long accountNoFrom=Long.parseLong(request.getParameter("accountNoFrom"));
		long accountNoTo=Long.parseLong(request.getParameter("accountNoTo"));
		int pinNumber=Integer.parseInt(request.getParameter("pinNumber"));
		float amount=Float.parseFloat(request.getParameter("amount"));
		try {
			boolean success= bankingServices.fundTransfer(accountNoTo, accountNoFrom, amount, pinNumber);
			RequestDispatcher dispatcher=request.getRequestDispatcher("fundsTransferDisplaySuccessful.jsp");
			dispatcher.forward(request, response);
		} catch (AccountNotFoundException | InsufficientAmountException
				| InvalidPinNumberException e) {
			String errorMessage=e.getMessage();
			request.setAttribute("errorMessage",errorMessage);
			RequestDispatcher dispatcher=request.getRequestDispatcher("fundsTransferPage.jsp");
			dispatcher.forward(request, response);
		}		
	}
}