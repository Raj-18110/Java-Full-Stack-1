package com.cg.banking.exceptions;

@SuppressWarnings("serial")
public class BankingServicesDownException extends Exception{
	private  String str;
	public BankingServicesDownException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BankingServicesDownException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public BankingServicesDownException(String message) {
		super(message);
		str = message;
	}

	public BankingServicesDownException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "BankingServicesDownException [" + str + "]";
	}
	
}
