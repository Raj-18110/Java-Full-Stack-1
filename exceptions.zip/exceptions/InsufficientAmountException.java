package com.cg.banking.exceptions;

@SuppressWarnings("serial")
public class InsufficientAmountException extends Exception {
	private  String str;
	public InsufficientAmountException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InsufficientAmountException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InsufficientAmountException(String message) {
		str = message;
	}

	public InsufficientAmountException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "InsufficientAmountException [" + str + "]";
	}

}
