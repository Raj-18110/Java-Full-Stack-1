package com.cg.banking.exceptions;

@SuppressWarnings("serial")
public class InvalidAmountException extends Exception{
	private  String str;
	public InvalidAmountException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidAmountException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidAmountException(String message) {
		super(message);
		str = message;
	}

	public InvalidAmountException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "InvalidAmountException [" + str + "]";
	}
	
}
