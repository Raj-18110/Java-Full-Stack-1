package com.cg.project.exceptions;
@SuppressWarnings("serial")
public class BankingServicesDownException extends Exception{

	public BankingServicesDownException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BankingServicesDownException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public BankingServicesDownException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public BankingServicesDownException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}