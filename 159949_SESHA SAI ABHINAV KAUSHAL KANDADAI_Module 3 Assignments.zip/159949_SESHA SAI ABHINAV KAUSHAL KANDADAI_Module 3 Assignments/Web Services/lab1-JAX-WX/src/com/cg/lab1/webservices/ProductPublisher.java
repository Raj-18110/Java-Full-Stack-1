package com.cg.lab1.webservices;

import javax.xml.ws.Endpoint;


public class ProductPublisher {

	public static void main(String[] args) {
		
			Endpoint.publish("http://127.0.0.1:9888/cs", new ProductDB());
			System.out.println("Web Service has been posted");

	}

}
