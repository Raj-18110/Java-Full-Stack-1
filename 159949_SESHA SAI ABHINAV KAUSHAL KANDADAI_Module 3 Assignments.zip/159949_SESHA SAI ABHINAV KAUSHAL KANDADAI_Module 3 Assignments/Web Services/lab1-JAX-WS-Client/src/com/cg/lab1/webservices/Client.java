package com.cg.lab1.webservices;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

public class Client {

	public static void main(String[] args) throws Exception {
URL url= new URL("http://localhost:9888/cs?wsdl");
		
		QName qname=new QName("http://webservices.lab1.cg.com/","ProductDBService");
		
		Service service=Service.create(url,qname);
		
		Product endPointIntf=service.getPort(Product.class);
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the product name");
		String product= scanner.next();
		float result=endPointIntf.findPrice(product);
		if(result==0)
			System.out.println("Product does not exist!!");
		else
		System.out.println("Price:\t"+result);

	}

}
