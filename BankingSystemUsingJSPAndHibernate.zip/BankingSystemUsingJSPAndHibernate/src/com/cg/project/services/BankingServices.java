package com.cg.project.services;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.project.beans.Account;
import com.cg.project.beans.Transaction;


public interface BankingServices {

	


	float depositAmount(long accountNo,float amount);

	float withdrawAmount(long accountNo,float amount,int pinNumber);

	boolean fundTransfer(long accountNoTo,long accountNoFrom,float transferAmount,int pinNumber) ;

	Account getAccountDetails(long accountNo);

	ArrayList<Account> getAllAccountDetails();

	ArrayList<Transaction> getAccountAllTransaction(long accountNo);


	

	Account openAccount(int pinNumber, String accountType, float initBalance,
			String fullName);

}