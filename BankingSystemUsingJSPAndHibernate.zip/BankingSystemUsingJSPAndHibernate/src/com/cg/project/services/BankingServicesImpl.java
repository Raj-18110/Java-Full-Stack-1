package com.cg.project.services;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.project.beans.Account;
import com.cg.project.beans.Transaction;
import com.cg.project.daoservices.AccountDAO;
import com.cg.project.daoservices.AccountDaoImpl;
public class BankingServicesImpl implements BankingServices {
	private AccountDAO accountdao=new AccountDaoImpl();
	@Override
	public Account openAccount(int pinNumber,String accountType, float initBalance,String fullName)
	{
		Account account=new Account(pinNumber, accountType, "Active", fullName, initBalance);
	
			accountdao.saveAccountDetails(account);
		
		return account;
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			{
			Account account;
				account = getAccountDetails(accountNo);
				account.setAccountBalance(account.getAccountBalance()+amount);
				Transaction transaction=new Transaction(amount, "Deposit",new Account(accountNo));
				accountdao.updateTransaction(transaction);
				accountdao.updateAccount(account);
			return account.getAccountBalance();
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber)  {
		Account account;
		
			account = getAccountDetails(accountNo);
			if(account.getAccountBalance()-amount>1000&&account.getPinNumber()==pinNumber){
				account.setAccountBalance(account.getAccountBalance()-amount);
				Transaction transaction=new Transaction(amount, "Withdraw",new Account(accountNo));
				accountdao.updateTransaction(transaction);
				accountdao.updateAccount(account);
			}
			else
				System.out.println("Insufficient Balance!!Withdrawal Failed");
			return account.getAccountBalance();
		
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			{
		Account account1;
			account1 = getAccountDetails(accountNoTo);
			Account account2=getAccountDetails(accountNoFrom);
			if(account2.getAccountBalance()-transferAmount>1000&&account2.getPinNumber()==pinNumber){
				account1.setAccountBalance(account1.getAccountBalance()+transferAmount);
				account2.setAccountBalance(account2.getAccountBalance()-transferAmount);
				Transaction transaction1=new Transaction(transferAmount, "Transfer",new Account(accountNoTo));
				Transaction transaction2=new Transaction(transferAmount, "Transfer",new Account(accountNoFrom));
				accountdao.updateTransaction(transaction1);
				accountdao.updateTransaction(transaction2);
				accountdao.updateAccount(account1);
				accountdao.updateAccount(account2);
			}
				else
					System.out.println("Insufficient Balance!!Withdrawal Failed");
		return false;
	}

	@Override
	public Account getAccountDetails(long accountNo)  {
				Account account=accountdao.getAccountDetails(accountNo);
				return account;		
	}

	@Override
	public ArrayList<Account> getAllAccountDetails() {
		
		return accountdao.getAllAccountDetails();
	}

	@Override
	public ArrayList<Transaction> getAccountAllTransaction(long accountNo)
			{	
		
		return accountdao.getAccountAllTransactionDetails(accountNo);
	}

	


}
