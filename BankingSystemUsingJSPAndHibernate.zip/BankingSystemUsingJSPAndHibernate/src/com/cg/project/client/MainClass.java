package com.cg.project.client;
import com.cg.project.services.BankingServices;
import com.cg.project.services.BankingServicesImpl;
public class MainClass {
	public static void main(String[] args)  {
		BankingServices services=new BankingServicesImpl();

		//System.out.println(services.openAccount("Savings", 1000, "suppu"));
//		System.out.println("Savings account opened with account number= "+accountNo);
//		long accountNo1= services.openAccount("Current", 5000, 2345, "Active");
//		System.out.println("Current account opened with account number= "+accountNo1);
//		//services.openAccount("Salary", 10000,3465,"Active");
//		float accBal=services.depositAmount(accountNo, 2000);
//		System.out.println(accBal);
//		//services.withdrawAmount(111114, 1000, 1234);
//		services.fundTransfer(accountNo,accountNo1 , 1000, 2345);
//		//System.out.println(services.accountStatus(10017));
//		//System.out.println(services.getAccountAllTransaction(accountNo).toString());		
	}
}