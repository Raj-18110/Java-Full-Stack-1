package com.cg.project.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.services.BankingServices;
import com.cg.project.services.BankingServicesImpl;


@WebServlet("/FundsTransfer")
public class FundsTransferServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public FundsTransferServlet() {
        super();
        
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BankingServices bankingServices=new BankingServicesImpl();
		long accountNoFrom=Long.parseLong(request.getParameter("accountNoFrom"));
		long accountNoTo=Long.parseLong(request.getParameter("accountNoTo"));
		int pinNumber=Integer.parseInt(request.getParameter("pinNumber"));
		float amount=Float.parseFloat(request.getParameter("amount"));
		boolean success= bankingServices.fundTransfer(accountNoTo, accountNoFrom, amount, pinNumber);
		RequestDispatcher dispatcher=request.getRequestDispatcher("fundsTransferDisplaySuccessful.jsp");
		dispatcher.forward(request, response);
	}

}
