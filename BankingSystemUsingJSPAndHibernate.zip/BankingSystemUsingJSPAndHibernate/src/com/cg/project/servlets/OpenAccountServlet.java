package com.cg.project.servlets;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.Account;
import com.cg.project.services.BankingServices;
import com.cg.project.services.BankingServicesImpl;
@WebServlet("/OpenAccount")
public class OpenAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
          
    public OpenAccountServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BankingServices bankingServices=new BankingServicesImpl();
		String accountType=(String) request.getParameter("accountType");
		int accountBalance=Integer.parseInt(request.getParameter("accountBalance"));
		String fullName=(String)request.getParameter("fullName");
		int pinNumber=Integer.parseInt(request.getParameter("pinNumber"));
		Account account=bankingServices.openAccount(pinNumber, accountType, accountBalance, fullName);
		request.setAttribute("account",account);
		RequestDispatcher dispatcher=request.getRequestDispatcher("displayNewAccountDetails.jsp");
		dispatcher.forward(request, response);
		
	}

}
