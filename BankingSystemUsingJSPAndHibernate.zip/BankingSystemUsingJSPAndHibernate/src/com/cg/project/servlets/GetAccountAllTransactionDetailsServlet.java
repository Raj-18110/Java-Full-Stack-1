package com.cg.project.servlets;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.Account;
import com.cg.project.beans.Transaction;
import com.cg.project.services.BankingServices;
import com.cg.project.services.BankingServicesImpl;


@WebServlet("/GetAccountAllTransactionDetails")
public class GetAccountAllTransactionDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public GetAccountAllTransactionDetailsServlet() {
        super();
       
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BankingServices bankingServices=new BankingServicesImpl();
		Long accountNo=Long.parseLong((request.getParameter("accountNo")));
		ArrayList<Transaction> transactions=bankingServices.getAccountAllTransaction(accountNo);
		request.setAttribute("transactions",transactions);
		RequestDispatcher dispatcher=request.getRequestDispatcher("displayAccountAllTransactionDetails.jsp");
		dispatcher.forward(request, response);
	}

}
