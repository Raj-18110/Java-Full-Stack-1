package com.cg.project.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.services.BankingServices;
import com.cg.project.services.BankingServicesImpl;

@WebServlet("/WithdrawAmount")
public class WithdrawAmountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public WithdrawAmountServlet() {
        super();
       
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BankingServices bankingServices=new BankingServicesImpl();
		long accountNo=Long.parseLong(request.getParameter("accountNo"));
		float amount=Float.parseFloat(request.getParameter("amount"));
		int pinNumber=Integer.parseInt(request.getParameter("pinNumber"));
		float accountBalance= bankingServices.withdrawAmount(accountNo, amount, pinNumber);
		request.setAttribute("accountBalance",accountBalance);
		RequestDispatcher dispatcher=request.getRequestDispatcher("withdrawDisplaySuccessful.jsp");
		dispatcher.forward(request, response);
	}

}
