package com.cg.banking.client;

import com.cg.banking.daoservices.AccountDaoImpl;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.services.BankingServicesImpl;

public final class MainClass {

	public static void main(String[] args) throws InsufficientAmountException {
		BankingServicesImpl ser = new BankingServicesImpl();
		ser.openAccount(1244, "savings", 10000, "shravan");
		
	}

}
