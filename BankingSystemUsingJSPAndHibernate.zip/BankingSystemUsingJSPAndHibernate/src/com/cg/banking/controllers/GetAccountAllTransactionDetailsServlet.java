package com.cg.banking.controllers;
import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
@WebServlet("/GetAccountAllTransactionDetails")
public class GetAccountAllTransactionDetailsServlet extends HttpServlet {
	Logger logger = Logger.getLogger(OpenAccountServlet.class);
	private static final long serialVersionUID = 1L;
    public GetAccountAllTransactionDetailsServlet() {}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PropertyConfigurator.configure("D:\\159949_Abhinav_Kaushal\\Advanced_Java\\BankingSystemUsingJSPAndHibernate\\WebContent\\WEB-INF\\log.properties");
		BankingServices bankingServices=new BankingServicesImpl();
		Long accountNo=Long.parseLong((request.getParameter("accountNo")));
		ArrayList<Transaction> transactions;
		try {
			transactions = bankingServices.getAccountAllTransaction(accountNo);
			logger.info("Transactions displayed of account no "+accountNo);
			request.setAttribute("transactions",transactions);
			RequestDispatcher dispatcher=request.getRequestDispatcher("displayAccountAllTransactionDetails.jsp");
			dispatcher.forward(request, response);
		} catch (AccountNotFoundException e) {
			String errorMessage=e.getMessage();
			logger.error(errorMessage);
			request.setAttribute("errorMessage",errorMessage);
			RequestDispatcher dispatcher=request.getRequestDispatcher("getAccountAllTransactionDetailsPage.jsp");
			dispatcher.forward(request, response);
		}		
	}
}