package com.cg.banking.controllers;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
@WebServlet("/OpenAccount")
public class OpenAccountServlet extends HttpServlet {
	Logger logger = Logger.getLogger(OpenAccountServlet.class);
	private static final long serialVersionUID = 1L;       
    public OpenAccountServlet() { }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PropertyConfigurator.configure("D:\\159953_Suprathik_Nikhil_Barigala\\Advanced_Java\\BankingSystemUsingJSPAndHibernate\\WebContent\\WEB-INF\\log.properties");
		BankingServices bankingServices=new BankingServicesImpl();
		String accountType=(String) request.getParameter("accountType");
		int accountBalance=Integer.parseInt(request.getParameter("accountBalance"));
		String fullName=(String)request.getParameter("fullName");
		int pinNumber=Integer.parseInt(request.getParameter("pinNumber"));
		Account account;
		try {
			account = bankingServices.openAccount(pinNumber, accountType, accountBalance, fullName);
			logger.info("New account saved  with account No"+account.getAccountNo());
			request.setAttribute("account",account);
			RequestDispatcher dispatcher=request.getRequestDispatcher("displayNewAccountDetails.jsp");
			dispatcher.forward(request, response);
		} catch (InsufficientAmountException e) {
			String errorMessage=e.getMessage();
			logger.error(errorMessage);
			request.setAttribute("errorMessage",errorMessage);
			RequestDispatcher dispatcher=request.getRequestDispatcher("openAccountPage.jsp");
			dispatcher.forward(request, response);
		}		
	}
}