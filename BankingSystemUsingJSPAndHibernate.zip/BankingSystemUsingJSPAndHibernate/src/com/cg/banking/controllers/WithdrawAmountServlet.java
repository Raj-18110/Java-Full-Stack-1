package com.cg.banking.controllers;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
@WebServlet("/WithdrawAmount")
public class WithdrawAmountServlet extends HttpServlet {
	Logger logger = Logger.getLogger(OpenAccountServlet.class);
	private static final long serialVersionUID = 1L;
    public WithdrawAmountServlet() { }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PropertyConfigurator.configure("D:\\159949_Abhinav_Kaushal\\Advanced_Java\\BankingSystemUsingJSPAndHibernate\\WebContent\\WEB-INF\\log.properties");
		BankingServices bankingServices=new BankingServicesImpl();
		long accountNo=Long.parseLong(request.getParameter("accountNo"));
		float amount=Float.parseFloat(request.getParameter("amount"));
		int pinNumber=Integer.parseInt(request.getParameter("pinNumber"));
		float accountBalance;
		try {
			accountBalance = bankingServices.withdrawAmount(accountNo, amount, pinNumber);
			logger.info(amount+" withdrawn successfully from account no "+accountNo);
			request.setAttribute("accountBalance",accountBalance);
			RequestDispatcher dispatcher=request.getRequestDispatcher("withdrawDisplaySuccessful.jsp");
			dispatcher.forward(request, response);
		} catch (AccountNotFoundException | InsufficientAmountException
				| InvalidPinNumberException e) {
			String errorMessage=e.getMessage();
			logger.error(errorMessage);
			request.setAttribute("errorMessage",errorMessage);
			RequestDispatcher dispatcher=request.getRequestDispatcher("withdrawAmountPage.jsp");
			dispatcher.forward(request, response);
		}	
	}
}