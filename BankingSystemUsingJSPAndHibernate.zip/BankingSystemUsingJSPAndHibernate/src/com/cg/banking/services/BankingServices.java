package com.cg.banking.services;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;


public interface BankingServices {

	


	float depositAmount(long accountNo,float amount) throws AccountNotFoundException;

	float withdrawAmount(long accountNo,float amount,int pinNumber) throws AccountNotFoundException, InsufficientAmountException, InvalidPinNumberException;

	boolean fundTransfer(long accountNoTo,long accountNoFrom,float transferAmount,int pinNumber) throws AccountNotFoundException, InsufficientAmountException, InvalidPinNumberException ;

	Account getAccountDetails(long accountNo) throws AccountNotFoundException;

	ArrayList<Account> getAllAccountDetails();

	ArrayList<Transaction> getAccountAllTransaction(long accountNo) throws AccountNotFoundException;


	

	Account openAccount(int pinNumber, String accountType, float initBalance,
			String fullName) throws InsufficientAmountException;

}