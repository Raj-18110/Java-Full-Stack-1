package com.cg.banking.services;
import java.util.ArrayList;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDaoImpl;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
public class BankingServicesImpl implements BankingServices {
	private AccountDAO accountdao=new AccountDaoImpl();
	@Override
	public Account openAccount(int pinNumber,String accountType, float initBalance,String fullName) throws InsufficientAmountException
	{
		if(initBalance<1000)throw new InsufficientAmountException("Opening balance be greater than 1000!!!");
		Account account=new Account(pinNumber, accountType, "Active", fullName, initBalance);
		accountdao.saveAccountDetails(account);
		return account;
	}

	@Override
	public float depositAmount(long accountNo, float amount) throws AccountNotFoundException
	{
		Account account;
		account = getAccountDetails(accountNo);
		if(account==null)throw new AccountNotFoundException("Account Details not found with the given account number!!!");
		account.setAccountBalance(account.getAccountBalance()+amount);
		Transaction transaction=new Transaction(amount, "Deposit",new Account(accountNo));
		accountdao.updateTransaction(transaction);
		accountdao.updateAccount(account);
		return account.getAccountBalance();
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws AccountNotFoundException, InsufficientAmountException, InvalidPinNumberException  {
		Account account;
		account = getAccountDetails(accountNo);
		if(account==null) throw new AccountNotFoundException("Account Details not found with the given account number!!!");
		if(account.getAccountBalance()-amount<1000) throw new InsufficientAmountException("Insufficient Balance!!!!");
		if(account.getPinNumber()!=pinNumber) throw new InvalidPinNumberException("Invalid Pin");
		account.setAccountBalance(account.getAccountBalance()-amount);
		Transaction transaction=new Transaction(amount, "Withdraw",new Account(accountNo));
		accountdao.updateTransaction(transaction);
		accountdao.updateAccount(account);
		return account.getAccountBalance();

	}
	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber) throws AccountNotFoundException, InsufficientAmountException, InvalidPinNumberException
	{
		Account account1;
		account1 = getAccountDetails(accountNoTo);
		if(account1==null)throw new AccountNotFoundException("Beneficiary Account Details not found withe the given account number!!!");
		Account account2=getAccountDetails(accountNoFrom);
		if(account2==null)throw new AccountNotFoundException("Account Details not found with the given account number");
		if(account2.getAccountBalance()-transferAmount<1000) throw new InsufficientAmountException("Insufficient Balance!!!");
		if(account2.getPinNumber()!=pinNumber) throw new InvalidPinNumberException("Invalid Pin");
		account1.setAccountBalance(account1.getAccountBalance()+transferAmount);
		account2.setAccountBalance(account2.getAccountBalance()-transferAmount);
		Transaction transaction1=new Transaction(transferAmount, "Transfer",new Account(accountNoTo));
		Transaction transaction2=new Transaction(transferAmount, "Transfer",new Account(accountNoFrom));
		accountdao.updateTransaction(transaction1);
		accountdao.updateTransaction(transaction2);
		accountdao.updateAccount(account1);
		accountdao.updateAccount(account2);
		return false;
	}
	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException  {
		Account account=accountdao.getAccountDetails(accountNo);
		if(account==null) throw new AccountNotFoundException("Account Details not found with the given account number!!!");
		return account;		
	}
	@Override
	public ArrayList<Account> getAllAccountDetails() {
		return accountdao.getAllAccountDetails();
	}
	@Override
	public ArrayList<Transaction> getAccountAllTransaction(long accountNo) throws AccountNotFoundException
	{	
		Account account=accountdao.getAccountDetails(accountNo);
		if(account==null) throw new AccountNotFoundException("Account Details not found with the given account number!!!");
		return accountdao.getAccountAllTransactionDetails(account);
	}
}