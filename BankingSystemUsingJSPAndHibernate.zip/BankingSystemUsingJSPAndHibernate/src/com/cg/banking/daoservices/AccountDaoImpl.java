package com.cg.banking.daoservices;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
public class AccountDaoImpl implements AccountDAO{
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
	@Override
	public Account saveAccountDetails(Account account) {
		EntityManager entityManager=factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(account);
		entityManager.getTransaction().commit();
		entityManager.close();
		return account;
	}
	@Override
	public Account getAccountDetails(long accountNo) {
		EntityManager entityManager=factory.createEntityManager();
		return entityManager.find(Account.class, accountNo);
	}
	
	@Override
	public boolean updateAccount(Account account) {
		EntityManager entityManager=factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(account);
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}
	@Override
	public ArrayList<Transaction> getAccountAllTransactionDetails(
			Account account) {
		EntityManager entityManager=factory.createEntityManager();
		Query query=entityManager.createQuery("from Transaction a where a.account=:account");
		query.setParameter("account", account);
		ArrayList<Transaction> list=(ArrayList<Transaction>)query.getResultList();
		return list;
	}
	@Override
	public ArrayList<Account> getAllAccountDetails() {
		EntityManager entityManager=factory.createEntityManager();
		Query query=entityManager.createNamedQuery("from Account a");
		ArrayList<Account> list=(ArrayList<Account>)query.getResultList();
		return list;
	}
	@Override
	public int updateTransaction(Transaction transaction) {
		EntityManager entityManager=factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(transaction);
		entityManager.getTransaction().commit();
		entityManager.close();
		return 1;
	}
}